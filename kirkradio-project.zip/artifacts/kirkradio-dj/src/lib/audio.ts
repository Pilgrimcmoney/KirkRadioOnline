export class DeckEngine {
  context: AudioContext;
  buffer: AudioBuffer | null = null;
  source: AudioBufferSourceNode | null = null;
  
  eqHigh: BiquadFilterNode;
  eqMid: BiquadFilterNode;
  eqLow: BiquadFilterNode;
  
  deckGain: GainNode;
  crossfaderGain: GainNode;
  analyser: AnalyserNode;
  
  // State
  isPlaying = false;
  playOffset = 0;
  lastPlayContextTime = 0;
  playbackRate = 1.0;
  isLooping = false;
  
  volume = 1.0;
  
  eqHighKill = false;
  eqMidKill = false;
  eqLowKill = false;
  
  eqHighVal = 0;
  eqMidVal = 0;
  eqLowVal = 0;
  
  onStateChange: () => void = () => {};
  
  constructor(context: AudioContext, masterNode: AudioNode) {
    this.context = context;
    
    // EQs
    this.eqHigh = context.createBiquadFilter();
    this.eqHigh.type = 'highshelf';
    this.eqHigh.frequency.value = 3200;
    
    this.eqMid = context.createBiquadFilter();
    this.eqMid.type = 'peaking';
    this.eqMid.frequency.value = 1000;
    this.eqMid.Q.value = 0.5;
    
    this.eqLow = context.createBiquadFilter();
    this.eqLow.type = 'lowshelf';
    this.eqLow.frequency.value = 320;
    
    this.deckGain = context.createGain();
    this.crossfaderGain = context.createGain();
    
    this.analyser = context.createAnalyser();
    this.analyser.fftSize = 512;
    this.analyser.smoothingTimeConstant = 0.5;
    
    // Connect chain: eqHigh -> eqMid -> eqLow -> deckGain -> crossfaderGain
    this.eqHigh.connect(this.eqMid);
    this.eqMid.connect(this.eqLow);
    this.eqLow.connect(this.deckGain);
    this.deckGain.connect(this.crossfaderGain);
    
    // Route crossfader out to both the local analyser AND the master mix
    this.crossfaderGain.connect(this.analyser);
    this.crossfaderGain.connect(masterNode);
    
    this.updateEQ();
  }

  get position() {
    if (!this.isPlaying) return this.playOffset;
    const pos = this.playOffset + (this.context.currentTime - this.lastPlayContextTime) * this.playbackRate;
    if (this.buffer && pos >= this.buffer.duration) {
      if (this.isLooping) {
        return pos % this.buffer.duration;
      }
      return this.buffer.duration;
    }
    return pos;
  }

  async loadBuffer(buffer: AudioBuffer) {
    this.pause();
    this.buffer = buffer;
    this.playOffset = 0;
    this.onStateChange();
  }

  play() {
    if (!this.buffer || this.isPlaying) return;
    
    this.source = this.context.createBufferSource();
    this.source.buffer = this.buffer;
    this.source.playbackRate.value = this.playbackRate;
    this.source.loop = this.isLooping;
    
    this.source.connect(this.eqHigh);
    
    this.lastPlayContextTime = this.context.currentTime;
    
    if (this.playOffset >= this.buffer.duration) {
      this.playOffset = 0;
    }
    
    this.source.start(0, this.playOffset);
    this.isPlaying = true;
    
    this.source.onended = () => {
      // If we're playing and hit the end naturally (no loop), stop
      if (this.isPlaying && !this.isLooping) {
        // Need to check if it really ended or was stopped
        // Actually, just let UI polling notice it reached the end
      }
    };
    
    this.onStateChange();
  }

  pause() {
    if (!this.isPlaying || !this.source) return;
    this.playOffset = this.position;
    this.source.stop();
    this.source.disconnect();
    this.source = null;
    this.isPlaying = false;
    this.onStateChange();
  }

  togglePlay() {
    if (this.isPlaying) this.pause();
    else this.play();
  }

  seek(time: number) {
    if (!this.buffer) return;
    const target = Math.max(0, Math.min(time, this.buffer.duration));
    if (this.isPlaying) {
      this.pause();
      this.playOffset = target;
      this.play();
    } else {
      this.playOffset = target;
      this.onStateChange();
    }
  }

  cue() {
    // Basic cue: jump to 0 and pause if playing
    this.seek(0);
    if (this.isPlaying) {
      this.pause();
    }
  }

  setPlaybackRate(rate: number) {
    if (this.isPlaying) {
      this.playOffset = this.position;
      this.lastPlayContextTime = this.context.currentTime;
      if (this.source) {
        this.source.playbackRate.value = rate;
      }
    }
    this.playbackRate = rate;
    this.onStateChange();
  }

  setVolume(vol: number) {
    this.volume = vol;
    this.deckGain.gain.value = vol;
    this.onStateChange();
  }

  setLooping(loop: boolean) {
    this.isLooping = loop;
    if (this.source) {
      this.source.loop = loop;
    }
    this.onStateChange();
  }
  
  updateEQ() {
    this.eqHigh.gain.value = this.eqHighKill ? -40 : this.eqHighVal;
    this.eqMid.gain.value = this.eqMidKill ? -40 : this.eqMidVal;
    this.eqLow.gain.value = this.eqLowKill ? -40 : this.eqLowVal;
    this.onStateChange();
  }

  setEQ(band: 'high' | 'mid' | 'low', val: number) {
    if (band === 'high') this.eqHighVal = val;
    if (band === 'mid') this.eqMidVal = val;
    if (band === 'low') this.eqLowVal = val;
    this.updateEQ();
  }

  toggleKill(band: 'high' | 'mid' | 'low') {
    if (band === 'high') this.eqHighKill = !this.eqHighKill;
    if (band === 'mid') this.eqMidKill = !this.eqMidKill;
    if (band === 'low') this.eqLowKill = !this.eqLowKill;
    this.updateEQ();
  }
}

export class AppAudioEngine {
  context: AudioContext;
  masterGain: GainNode;
  masterAnalyser: AnalyserNode;
  destinationStream: MediaStreamAudioDestinationNode;
  
  deckA: DeckEngine;
  deckB: DeckEngine;
  
  crossfader = 0.5;
  masterVolume = 1.0;

  // Mic (talkover) channel
  micGain: GainNode;
  micAnalyser: AnalyserNode;
  micStream: MediaStream | null = null;
  micSource: MediaStreamAudioSourceNode | null = null;
  micEnabled = false;
  micMuted = true;
  micVolume = 1.0;
  micPending = false;
  micError: string | null = null;
  pushToTalkActive = false;
  
  onStateChange: () => void = () => {};

  constructor() {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    this.context = new AudioContextClass();
    
    this.masterGain = this.context.createGain();
    this.masterAnalyser = this.context.createAnalyser();
    this.masterAnalyser.fftSize = 512;
    this.masterAnalyser.smoothingTimeConstant = 0.5;
    
    this.destinationStream = this.context.createMediaStreamDestination();
    
    this.masterGain.connect(this.masterAnalyser);
    this.masterAnalyser.connect(this.context.destination);
    this.masterAnalyser.connect(this.destinationStream);
    
    this.deckA = new DeckEngine(this.context, this.masterGain);
    this.deckB = new DeckEngine(this.context, this.masterGain);
    
    this.deckA.onStateChange = () => this.onStateChange();
    this.deckB.onStateChange = () => this.onStateChange();

    // Mic routes straight into the master bus (talk-over mic on a broadcast desk)
    this.micGain = this.context.createGain();
    this.micGain.gain.value = this.micMuted ? 0 : this.micVolume;
    this.micAnalyser = this.context.createAnalyser();
    this.micAnalyser.fftSize = 512;
    this.micAnalyser.smoothingTimeConstant = 0.5;
    this.micGain.connect(this.masterGain);
    this.micGain.connect(this.micAnalyser);
    
    this.setCrossfader(0.5);
  }
  
  resume() {
    if (this.context.state === 'suspended') {
      this.context.resume();
    }
  }

  setCrossfader(val: number) {
    this.crossfader = Math.max(0, Math.min(1, val));
    // Constant power crossfade
    const gainA = Math.cos(this.crossfader * 0.5 * Math.PI);
    const gainB = Math.cos((1.0 - this.crossfader) * 0.5 * Math.PI);
    this.deckA.crossfaderGain.gain.value = gainA;
    this.deckB.crossfaderGain.gain.value = gainB;
    this.onStateChange();
  }
  
  setMasterVolume(vol: number) {
    this.masterVolume = vol;
    this.masterGain.gain.value = vol;
    this.onStateChange();
  }

  async enableMic() {
    if (this.micEnabled || this.micPending) return;
    this.micPending = true;
    this.micError = null;
    this.onStateChange();

    try {
      this.resume();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      this.micStream = stream;
      this.micSource = this.context.createMediaStreamSource(stream);
      this.micSource.connect(this.micGain);
      this.micEnabled = true;
    } catch (err) {
      this.micError = err instanceof Error ? err.message : 'Microphone access denied';
      this.micEnabled = false;
    } finally {
      this.micPending = false;
      this.onStateChange();
    }
  }

  disableMic() {
    if (this.micSource) {
      this.micSource.disconnect();
      this.micSource = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    this.micEnabled = false;
    this.pushToTalkActive = false;
    this.onStateChange();
  }

  toggleMic() {
    if (this.micEnabled) {
      this.disableMic();
    } else {
      this.enableMic();
    }
  }

  setMicVolume(vol: number) {
    this.micVolume = Math.max(0, Math.min(1.5, vol));
    this.updateMicGain();
    this.onStateChange();
  }

  toggleMicMute() {
    this.micMuted = !this.micMuted;
    this.updateMicGain();
    this.onStateChange();
  }

  private updateMicGain() {
    const isOpen = this.pushToTalkActive || !this.micMuted;
    this.micGain.gain.value = isOpen ? this.micVolume : 0;
  }

  /** Push-to-talk: opens the mic while held, regardless of the mute toggle. */
  async pressTalk() {
    if (!this.micEnabled && !this.micPending) {
      await this.enableMic();
    }
    this.pushToTalkActive = true;
    this.updateMicGain();
    this.onStateChange();
  }

  releaseTalk() {
    this.pushToTalkActive = false;
    this.updateMicGain();
    this.onStateChange();
  }
}

// Singleton instance
let _engine: AppAudioEngine | null = null;
export function getAudioEngine() {
  if (!_engine) {
    _engine = new AppAudioEngine();
  }
  return _engine;
}
