import React, { useState, useEffect, useRef } from 'react';
import { AppAudioEngine, getAudioEngine } from '../lib/audio';

export function useAudioEngine() {
  const [engine, setEngine] = useState<AppAudioEngine | null>(null);
  const [renderTick, setRenderTick] = useState(0);

  useEffect(() => {
    const instance = getAudioEngine();
    setEngine(instance);
    
    instance.onStateChange = () => {
      setRenderTick(t => t + 1);
    };
    
    return () => {
      instance.onStateChange = () => {};
    };
  }, []);

  return engine;
}
