import React, { useRef, useState, useEffect } from 'react';

interface KnobProps {
  value: number;
  min: number;
  max: number;
  onChange: (val: number) => void;
  label: string;
  size?: number;
}

export function Knob({ value, min, max, onChange, label, size = 48 }: KnobProps) {
  const [isDragging, setIsDragging] = useState(false);
  const startY = useRef(0);
  const startVal = useRef(0);
  
  const clamp = (v: number) => Math.max(min, Math.min(max, v));
  
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    startY.current = e.clientY;
    startVal.current = value;
    e.preventDefault();
  };

  useEffect(() => {
    if (!isDragging) return;
    
    const handleMouseMove = (e: MouseEvent) => {
      const deltaY = startY.current - e.clientY;
      const range = max - min;
      // 100px drag = full range
      const newVal = startVal.current + (deltaY / 100) * range;
      onChange(clamp(newVal));
    };
    
    const handleMouseUp = () => {
      setIsDragging(false);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, min, max, onChange]);

  // map value to degrees: -135 to +135
  const percentage = (value - min) / (max - min);
  const degrees = -135 + (percentage * 270);

  return (
    <div className="flex flex-col items-center gap-1 select-none">
      <div 
        className="relative rounded-full bg-zinc-800 border-2 border-zinc-950 shadow-inner flex items-center justify-center cursor-ns-resize"
        style={{ width: size, height: size }}
        onMouseDown={handleMouseDown}
      >
        <div 
          className="w-full h-full rounded-full absolute"
          style={{ transform: `rotate(${degrees}deg)` }}
        >
          {/* Indicator line */}
          <div className="absolute top-1 left-1/2 -translate-x-1/2 w-1 h-3 bg-white rounded-full shadow-[0_0_5px_rgba(255,255,255,0.5)]" />
        </div>
      </div>
      <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider">{label}</span>
    </div>
  );
}
