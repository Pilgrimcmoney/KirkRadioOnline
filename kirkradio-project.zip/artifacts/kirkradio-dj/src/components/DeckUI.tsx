import React from 'react';
import { DeckEngine } from '../lib/audio';
import { Waveform } from './Waveform';
import { Knob } from './Knob';
import { Play, Pause, SkipBack, Repeat, Upload } from 'lucide-react';
import { VUMeter } from './VUMeter';

export function DeckUI({ deck, label }: { deck: DeckEngine, label: string }) {
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    deck.context.resume();
    
    const arrayBuffer = await file.arrayBuffer();
    try {
      const audioBuffer = await deck.context.decodeAudioData(arrayBuffer);
      await deck.loadBuffer(audioBuffer);
    } catch (err) {
      console.error("Failed to decode audio", err);
      alert("Failed to decode audio file.");
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${m}:${s.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  const [timeStr, setTimeStr] = React.useState("0:00.00");
  
  React.useEffect(() => {
    let id: number;
    const loop = () => {
      id = requestAnimationFrame(loop);
      setTimeStr(formatTime(deck.position));
    };
    loop();
    return () => cancelAnimationFrame(id);
  }, [deck]);

  return (
    <div className="flex flex-col bg-zinc-950 border border-zinc-800 rounded-xl overflow-hidden flex-1 shadow-xl">
      {/* Deck Header */}
      <div className="flex justify-between items-center px-4 py-2 bg-zinc-900 border-b border-zinc-800">
        <h2 className="text-xl font-black tracking-widest text-zinc-500 uppercase">{label}</h2>
        <div className="font-mono text-lg text-primary animate-in fade-in tabular-nums">
          {timeStr}
        </div>
      </div>
      
      {/* Waveform Area */}
      <div className="p-4 bg-zinc-950 relative">
        {!deck.buffer ? (
          <div className="w-full h-24 border-2 border-dashed border-zinc-800 rounded-md flex items-center justify-center text-zinc-600">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 hover:text-white transition-colors"
            >
              <Upload size={18} /> Load Track
            </button>
            <input 
              type="file" 
              accept="audio/*" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleFileChange}
            />
          </div>
        ) : (
          <Waveform deck={deck} />
        )}
      </div>
      
      {/* Controls Area */}
      <div className="flex flex-1 p-4 gap-6 bg-zinc-900/50">
        
        {/* Playback Controls */}
        <div className="flex flex-col gap-4 justify-end flex-1">
          <div className="flex gap-2">
            <button 
              className={`flex-1 h-16 rounded-md flex items-center justify-center bg-zinc-800 border-b-4 border-zinc-950 active:border-b-0 active:translate-y-1 transition-all ${deck.isPlaying ? 'text-primary shadow-[0_0_15px_rgba(234,88,12,0.3)]' : 'text-white'}`}
              onClick={() => deck.togglePlay()}
            >
              {deck.isPlaying ? <Pause size={32} /> : <Play size={32} className="ml-2" />}
            </button>
            <button 
              className="w-16 h-16 rounded-md flex items-center justify-center bg-zinc-800 border-b-4 border-zinc-950 active:border-b-0 active:translate-y-1 text-white transition-all"
              onClick={() => deck.cue()}
            >
              <SkipBack size={24} />
            </button>
          </div>
          
          <div className="flex items-center justify-between bg-zinc-950 p-2 rounded-md border border-zinc-800">
             <button 
                className={`p-2 rounded ${deck.isLooping ? 'bg-primary/20 text-primary' : 'text-zinc-500 hover:text-white'}`}
                onClick={() => deck.setLooping(!deck.isLooping)}
              >
                <Repeat size={20} />
             </button>
             <div className="text-xs font-mono text-zinc-500 flex items-center gap-2">
               RATE: 
               <span className="text-white w-12 text-right">{(deck.playbackRate * 100).toFixed(0)}%</span>
             </div>
          </div>
        </div>

        {/* Pitch Fader */}
        <div className="flex flex-col items-center bg-zinc-950 p-3 rounded-lg border border-zinc-800 h-48 w-16">
           <span className="text-[10px] font-mono text-zinc-500 mb-2">PITCH</span>
           <input 
             type="range" 
             className="dj-fader dj-fader-vertical flex-1"
             min="0.5" max="1.5" step="0.01" 
             value={deck.playbackRate}
             onChange={(e) => deck.setPlaybackRate(parseFloat(e.target.value))}
             onDoubleClick={() => deck.setPlaybackRate(1.0)}
           />
        </div>

      </div>
    </div>
  );
}
