import React, { useRef, useEffect } from 'react';
import { DeckEngine } from '../lib/audio';

interface WaveformProps {
  deck: DeckEngine;
  width?: number;
  height?: number;
}

export function Waveform({ deck, width = 600, height = 100 }: WaveformProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Static rendering of the whole file
  useEffect(() => {
    if (!deck.buffer || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set internal resolution based on props
    canvas.width = width;
    canvas.height = height;
    
    ctx.clearRect(0, 0, width, height);
    
    const channelData = deck.buffer.getChannelData(0); // Use left channel for display
    const step = Math.ceil(channelData.length / width);
    const amp = height / 2;
    
    ctx.fillStyle = '#ea580c'; // The accent color (amber-600)
    
    for (let i = 0; i < width; i++) {
      let min = 1.0;
      let max = -1.0;
      for (let j = 0; j < step; j++) {
        const datum = channelData[i * step + j];
        if (datum < min) min = datum;
        if (datum > max) max = datum;
      }
      
      const y = (1 + min) * amp;
      const h = Math.max(1, (max - min) * amp);
      ctx.fillRect(i, y, 1, h);
    }
  }, [deck.buffer, width, height]);

  // Dynamic playhead
  useEffect(() => {
    if (!deck.buffer || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const duration = deck.buffer.duration;
    
    const drawOverlay = () => {
      animationId = requestAnimationFrame(drawOverlay);
      
      const pos = deck.position;
      const percent = pos / duration;
      const x = percent * width;
      
      // We can't easily clear just the playhead without clearing the waveform.
      // Easiest trick: Overlay div for playhead, or use a separate canvas overlay.
      // Let's use a separate absolute div in the parent component instead of canvas drawing for the playhead.
    };
    
    drawOverlay();
    return () => cancelAnimationFrame(animationId);
  }, [deck, width]);

  return (
    <div className="relative w-full h-24 bg-zinc-900 border border-zinc-800 rounded-md overflow-hidden cursor-pointer" 
         onClick={(e) => {
           if (!deck.buffer) return;
           const rect = e.currentTarget.getBoundingClientRect();
           const percent = (e.clientX - rect.left) / rect.width;
           deck.seek(percent * deck.buffer.duration);
         }}>
      <canvas 
        ref={canvasRef} 
        className="waveform-canvas absolute inset-0 w-full h-full opacity-80" 
      />
      <Playhead deck={deck} />
    </div>
  );
}

function Playhead({ deck }: { deck: DeckEngine }) {
  const [percent, setPercent] = React.useState(0);
  
  useEffect(() => {
    let animationId: number;
    const update = () => {
      animationId = requestAnimationFrame(update);
      if (deck.buffer) {
        setPercent((deck.position / deck.buffer.duration) * 100);
      } else {
        setPercent(0);
      }
    };
    update();
    return () => cancelAnimationFrame(animationId);
  }, [deck]);

  return (
    <div 
      className="absolute top-0 bottom-0 w-0.5 bg-white pointer-events-none shadow-[0_0_8px_rgba(255,255,255,0.8)]"
      style={{ left: `${percent}%` }}
    />
  );
}
