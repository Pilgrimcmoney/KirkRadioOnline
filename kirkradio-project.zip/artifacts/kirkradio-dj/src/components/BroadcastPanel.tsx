import React, { useState, useEffect, useRef } from 'react';
import { 
  useGetBroadcastStatus, 
  useStartBroadcast, 
  useStopBroadcast, 
  getGetBroadcastStatusQueryKey 
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppAudioEngine } from '../lib/audio';
import { Radio, AlertCircle, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export function BroadcastPanel({ engine }: { engine: AppAudioEngine }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [streamTitle, setStreamTitle] = useState('Live DJ Set');
  const [wsStatus, setWsStatus] = useState<'offline' | 'connecting' | 'live' | 'error'>('offline');
  
  const wsRef = useRef<WebSocket | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const { data: status, isLoading } = useGetBroadcastStatus({
    query: {
      queryKey: getGetBroadcastStatusQueryKey(),
      refetchInterval: 5000 // Poll every 5s
    }
  });

  const startBroadcast = useStartBroadcast({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetBroadcastStatusQueryKey() });
        startStreaming();
      },
      onError: (err: any) => {
        toast({
          title: "Broadcast Failed",
          description: err?.error || "Could not start broadcast.",
          variant: "destructive"
        });
      }
    }
  });

  const stopBroadcast = useStopBroadcast({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetBroadcastStatusQueryKey() });
        stopStreaming();
      }
    }
  });

  // Sync WS streaming with backend Live status
  // If backend says live, and we aren't streaming, start.
  // If backend says offline, and we are streaming, stop.
  useEffect(() => {
    if (status?.isLive && wsStatus === 'offline') {
      startStreaming();
    } else if (!status?.isLive && (wsStatus === 'live' || wsStatus === 'connecting')) {
      stopStreaming();
    }
    // Cleanup on unmount
    return () => {
      // Don't auto stop backend broadcast on unmount, but stop local stream sending
    };
  }, [status?.isLive]);

  const startStreaming = () => {
    if (wsStatus === 'live' || wsStatus === 'connecting') return;
    setWsStatus('connecting');

    try {
      // Ensure audio context is running
      if (engine.context.state === 'suspended') {
        engine.context.resume();
      }

      const loc = window.location;
      const wsProtocol = loc.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${wsProtocol}//${loc.host}${import.meta.env.BASE_URL}api/broadcast/ws`;
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsStatus('live');
        
        // Start recording
        const destStream = engine.destinationStream.stream;
        const mediaRecorder = new MediaRecorder(destStream, {
          mimeType: 'audio/webm;codecs=opus'
        });
        
        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0 && ws.readyState === WebSocket.OPEN) {
            ws.send(e.data);
          }
        };
        
        mediaRecorder.start(250); // 250ms chunks
        mediaRecorderRef.current = mediaRecorder;
      };

      ws.onerror = (e) => {
        console.error("WS Error", e);
        setWsStatus('error');
      };

      ws.onclose = () => {
        if (wsStatus !== 'offline') {
          setWsStatus('offline');
        }
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
          mediaRecorderRef.current.stop();
        }
      };

    } catch (err) {
      console.error(err);
      setWsStatus('error');
    }
  };

  const stopStreaming = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.close();
    }
    setWsStatus('offline');
  };

  const handleToggleBroadcast = () => {
    if (status?.isLive) {
      stopBroadcast.mutate();
    } else {
      startBroadcast.mutate({ data: { streamTitle } });
    }
  };

  return (
    <div className={`p-6 rounded-xl border flex flex-col gap-4 shadow-xl transition-all duration-500 ${
      status?.isLive ? 'bg-zinc-950 border-primary/50 on-air-glow' : 'bg-zinc-900 border-zinc-800'
    }`}>
       <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Radio className={status?.isLive ? 'text-primary animate-pulse' : 'text-zinc-600'} size={28} />
            <h2 className="text-xl font-black uppercase tracking-widest text-white">Broadcast</h2>
          </div>
          
          {status?.isLive && (
            <div className="px-3 py-1 bg-red-600 text-white font-bold text-xs tracking-widest rounded animate-pulse shadow-[0_0_10px_rgba(220,38,38,0.8)]">
              ON AIR
            </div>
          )}
       </div>

       {isLoading ? (
         <div className="text-zinc-500 text-sm flex items-center gap-2"><RefreshCw className="animate-spin" size={14}/> Polling status...</div>
       ) : !status?.configured ? (
         <div className="p-4 bg-red-950/30 border border-red-900/50 rounded-lg flex items-start gap-3">
           <AlertCircle className="text-red-500 mt-0.5 shrink-0" size={18} />
           <div className="text-sm text-red-200">
             Stream credentials not configured on the server. Broadcasting disabled.
           </div>
         </div>
       ) : (
         <div className="flex flex-col gap-4">
           
           <div className="flex flex-col gap-2">
             <label className="text-xs font-mono text-zinc-400">STREAM TITLE</label>
             <Input 
               value={streamTitle}
               onChange={e => setStreamTitle(e.target.value)}
               disabled={status?.isLive || startBroadcast.isPending}
               className="bg-zinc-950 border-zinc-800 font-mono focus-visible:ring-primary"
             />
           </div>

           <Button 
             onClick={handleToggleBroadcast}
             disabled={startBroadcast.isPending || stopBroadcast.isPending}
             variant={status?.isLive ? 'destructive' : 'default'}
             className={`w-full py-6 font-black tracking-widest uppercase transition-all ${
               !status?.isLive ? 'bg-primary hover:bg-primary/90 text-white shadow-[0_0_15px_rgba(234,88,12,0.4)]' : ''
             }`}
           >
             {startBroadcast.isPending || stopBroadcast.isPending ? 'Processing...' : status?.isLive ? 'Stop Broadcast' : 'Go Live'}
           </Button>

           <div className="text-xs font-mono flex items-center justify-between text-zinc-500 mt-2">
             <span>CONNECTION: 
               <span className={`ml-2 ${
                 wsStatus === 'live' ? 'text-green-500' : 
                 wsStatus === 'connecting' ? 'text-yellow-500' : 
                 wsStatus === 'error' ? 'text-red-500' : 'text-zinc-600'
               }`}>
                 {wsStatus.toUpperCase()}
               </span>
             </span>
             {status?.startedAt && (
               <span>Started: {new Date(status.startedAt).toLocaleTimeString()}</span>
             )}
           </div>

         </div>
       )}
    </div>
  );
}
