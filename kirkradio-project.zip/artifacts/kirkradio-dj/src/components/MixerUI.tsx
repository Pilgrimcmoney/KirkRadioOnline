import React from 'react';
import { AppAudioEngine } from '../lib/audio';
import { Knob } from './Knob';
import { VUMeter } from './VUMeter';
import { Mic, MicOff } from 'lucide-react';

export function MixerUI({ engine }: { engine: AppAudioEngine }) {
  
  return (
    <div className="flex flex-col bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl overflow-hidden w-96 flex-shrink-0">
       <div className="px-4 py-2 bg-zinc-950 border-b border-zinc-800 text-center">
         <h2 className="text-lg font-black tracking-widest text-zinc-400">MIXER</h2>
       </div>

       <div className="flex flex-1 p-4 gap-4">
          
          {/* Deck A Channel */}
          <div className="flex flex-col items-center flex-1 gap-6">
             <div className="flex flex-col gap-4 p-3 bg-zinc-950 rounded-lg border border-zinc-800">
               <Knob value={engine.deckA.eqHighVal} min={-15} max={15} onChange={v => engine.deckA.setEQ('high', v)} label="HIGH" />
               <Knob value={engine.deckA.eqMidVal} min={-15} max={15} onChange={v => engine.deckA.setEQ('mid', v)} label="MID" />
               <Knob value={engine.deckA.eqLowVal} min={-15} max={15} onChange={v => engine.deckA.setEQ('low', v)} label="LOW" />
             </div>
             
             <div className="flex items-stretch gap-2 h-48 w-full justify-center">
               <div className="w-4 h-full">
                 <VUMeter analyser={engine.deckA.analyser} orientation="vertical" />
               </div>
               <input 
                 type="range" 
                 className="dj-fader dj-fader-vertical"
                 min="0" max="1" step="0.01" 
                 value={engine.deckA.volume}
                 onChange={(e) => engine.deckA.setVolume(parseFloat(e.target.value))}
               />
             </div>
          </div>

          {/* Master Channel (Center) */}
          <div className="flex flex-col items-center justify-between w-16">
             <div className="flex flex-col items-center gap-2 mt-4">
                <span className="text-xs font-black text-primary tracking-widest">MASTER</span>
                <Knob value={engine.masterVolume} min={0} max={1} onChange={v => engine.setMasterVolume(v)} label="VOL" size={56} />
             </div>

             <div className="flex items-stretch gap-1 h-32 mb-6">
                 <div className="w-3 h-full">
                   <VUMeter analyser={engine.masterAnalyser} orientation="vertical" />
                 </div>
                 <div className="w-3 h-full">
                   <VUMeter analyser={engine.masterAnalyser} orientation="vertical" />
                 </div>
             </div>
          </div>

          {/* Mic Channel */}
          <div className="flex flex-col items-center gap-3 w-16">
             <button
               onClick={() => engine.toggleMic()}
               disabled={engine.micPending}
               title={engine.micEnabled ? 'Disable mic' : 'Enable mic'}
               className={`p-2 rounded-full border transition-all ${
                 engine.micEnabled
                   ? 'bg-primary/20 border-primary text-primary on-air-glow'
                   : 'bg-zinc-950 border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700'
               } ${engine.micPending ? 'opacity-50 cursor-wait' : ''}`}
             >
               {engine.micEnabled ? <Mic size={18} /> : <MicOff size={18} />}
             </button>
             <span className="text-[10px] font-black text-zinc-500 tracking-widest">MIC</span>

             {engine.micError ? (
               <span className="text-[9px] text-red-500 text-center leading-tight px-1">{engine.micError}</span>
             ) : (
               <div className="flex items-stretch gap-2 h-32">
                 <div className="w-3 h-full">
                   <VUMeter analyser={engine.micAnalyser} orientation="vertical" />
                 </div>
                 <input
                   type="range"
                   className="dj-fader dj-fader-vertical"
                   min="0" max="1.5" step="0.01"
                   value={engine.micVolume}
                   disabled={!engine.micEnabled}
                   onChange={(e) => engine.setMicVolume(parseFloat(e.target.value))}
                 />
               </div>
             )}

             <button
               onMouseDown={(e) => { e.preventDefault(); engine.pressTalk(); }}
               onMouseUp={() => engine.releaseTalk()}
               onMouseLeave={() => engine.pushToTalkActive && engine.releaseTalk()}
               onTouchStart={(e) => { e.preventDefault(); engine.pressTalk(); }}
               onTouchEnd={() => engine.releaseTalk()}
               disabled={engine.micPending}
               title="Hold to talk over the mix"
               className={`w-full py-2 rounded-lg border text-[10px] font-black tracking-widest uppercase transition-all select-none ${
                 engine.pushToTalkActive
                   ? 'bg-primary border-primary text-white on-air-glow scale-95'
                   : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
               } ${engine.micPending ? 'opacity-50 cursor-wait' : ''}`}
             >
               Talk
             </button>

             <button
               onClick={() => engine.toggleMicMute()}
               disabled={!engine.micEnabled}
               title="Keep mic open without holding Talk"
               className={`text-[9px] font-black px-2 py-1 rounded transition-colors ${
                 !engine.micMuted
                   ? 'bg-primary/20 text-primary border border-primary/40'
                   : 'bg-zinc-950 text-zinc-500 border border-zinc-800'
               } ${!engine.micEnabled ? 'opacity-40' : ''}`}
             >
               {engine.micMuted ? 'OPEN MIC' : 'LOCKED OPEN'}
             </button>
          </div>

          {/* Deck B Channel */}
          <div className="flex flex-col items-center flex-1 gap-6">
             <div className="flex flex-col gap-4 p-3 bg-zinc-950 rounded-lg border border-zinc-800">
               <Knob value={engine.deckB.eqHighVal} min={-15} max={15} onChange={v => engine.deckB.setEQ('high', v)} label="HIGH" />
               <Knob value={engine.deckB.eqMidVal} min={-15} max={15} onChange={v => engine.deckB.setEQ('mid', v)} label="MID" />
               <Knob value={engine.deckB.eqLowVal} min={-15} max={15} onChange={v => engine.deckB.setEQ('low', v)} label="LOW" />
             </div>
             
             <div className="flex items-stretch gap-2 h-48 w-full justify-center">
               <input 
                 type="range" 
                 className="dj-fader dj-fader-vertical"
                 min="0" max="1" step="0.01" 
                 value={engine.deckB.volume}
                 onChange={(e) => engine.deckB.setVolume(parseFloat(e.target.value))}
               />
               <div className="w-4 h-full">
                 <VUMeter analyser={engine.deckB.analyser} orientation="vertical" />
               </div>
             </div>
          </div>
       </div>

       {/* Crossfader */}
       <div className="p-6 bg-zinc-950 border-t border-zinc-800 flex flex-col items-center">
          <input 
             type="range" 
             className="dj-fader w-full max-w-[250px]"
             min="0" max="1" step="0.01" 
             value={engine.crossfader}
             onChange={(e) => engine.setCrossfader(parseFloat(e.target.value))}
             onDoubleClick={() => engine.setCrossfader(0.5)}
          />
          <div className="flex justify-between w-full max-w-[250px] mt-2 text-[10px] text-zinc-500 font-black">
             <span>A</span>
             <span>B</span>
          </div>
       </div>
    </div>
  );
}
