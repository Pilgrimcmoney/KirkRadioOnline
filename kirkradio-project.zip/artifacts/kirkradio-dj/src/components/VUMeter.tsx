import React, { useRef, useEffect } from 'react';

interface VUMeterProps {
  analyser: AnalyserNode | null;
  orientation?: 'vertical' | 'horizontal';
}

export function VUMeter({ analyser, orientation = 'vertical' }: VUMeterProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!analyser || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    const draw = () => {
      animationId = requestAnimationFrame(draw);
      
      analyser.getByteTimeDomainData(dataArray);
      
      // Calculate RMS
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        const val = (dataArray[i] - 128) / 128; // -1 to 1
        sum += val * val;
      }
      const rms = Math.sqrt(sum / dataArray.length);
      
      // Convert to dB (-60 to 0) roughly
      let db = 20 * Math.log10(rms > 0.001 ? rms : 0.001);
      
      // Map dB to 0-1 (e.g., min -40dB, max 0dB)
      const minDb = -40;
      let level = (db - minDb) / (-minDb);
      level = Math.max(0, Math.min(1, level));

      // Draw
      const w = canvas.width;
      const h = canvas.height;
      
      ctx.clearRect(0, 0, w, h);
      
      const segments = 20;
      const spacing = 2;
      
      if (orientation === 'vertical') {
        const segH = (h - (segments - 1) * spacing) / segments;
        for (let i = 0; i < segments; i++) {
          const segLevel = (segments - i) / segments;
          const y = i * (segH + spacing);
          
          if (level >= segLevel) {
            // Colors: bottom green, middle yellow, top red
            if (i < 3) ctx.fillStyle = '#ef4444'; // Red
            else if (i < 8) ctx.fillStyle = '#f59e0b'; // Yellow
            else ctx.fillStyle = '#22c55e'; // Green
          } else {
            ctx.fillStyle = '#27272a'; // Dark gray (bg)
          }
          
          ctx.fillRect(0, y, w, segH);
        }
      } else {
        const segW = (w - (segments - 1) * spacing) / segments;
        for (let i = 0; i < segments; i++) {
          const segLevel = (i + 1) / segments;
          const x = i * (segW + spacing);
          
          if (level >= segLevel) {
             if (i >= segments - 3) ctx.fillStyle = '#ef4444';
             else if (i >= segments - 8) ctx.fillStyle = '#f59e0b';
             else ctx.fillStyle = '#22c55e';
          } else {
            ctx.fillStyle = '#27272a';
          }
          ctx.fillRect(x, 0, segW, h);
        }
      }
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [analyser, orientation]);

  return (
    <canvas 
      ref={canvasRef} 
      className="bg-zinc-900 rounded-sm w-full h-full"
      width={orientation === 'vertical' ? 16 : 100}
      height={orientation === 'vertical' ? 100 : 16}
    />
  );
}
