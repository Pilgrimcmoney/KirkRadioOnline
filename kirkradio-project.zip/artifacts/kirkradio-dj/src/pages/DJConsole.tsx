import React from 'react';
import { useAudioEngine } from '../hooks/use-audio';
import { DeckUI } from '../components/DeckUI';
import { MixerUI } from '../components/MixerUI';
import { BroadcastPanel } from '../components/BroadcastPanel';
import { Headphones } from 'lucide-react';

export function DJConsole() {
  const engine = useAudioEngine();

  if (!engine) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-zinc-500">
        Initializing Audio Engine...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans select-none overflow-hidden">
      
      {/* Top Bar */}
      <header className="h-16 bg-zinc-950 border-b border-zinc-900 flex items-center justify-between px-6 shrink-0">
         <div className="flex items-center gap-3">
           <Headphones className="text-primary" size={28} />
           <h1 className="text-2xl font-black tracking-widest text-zinc-100">KIRK<span className="text-primary">RADIO</span> DJ</h1>
         </div>
         <div className="text-xs font-mono text-zinc-600 bg-zinc-900 px-3 py-1 rounded">
           WEB AUDIO API LIVE
         </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex flex-col p-6 gap-6 overflow-y-auto">
         
         <div className="flex flex-col lg:flex-row gap-6 items-stretch justify-center h-full max-h-[800px]">
            {/* Deck A */}
            <DeckUI deck={engine.deckA} label="Deck A" />
            
            {/* Center Mixer */}
            <MixerUI engine={engine} />
            
            {/* Deck B */}
            <DeckUI deck={engine.deckB} label="Deck B" />
         </div>

         {/* Broadcast Footer Panel */}
         <div className="max-w-3xl mx-auto w-full mt-auto">
            <BroadcastPanel engine={engine} />
         </div>
         
      </main>
      
    </div>
  );
}
