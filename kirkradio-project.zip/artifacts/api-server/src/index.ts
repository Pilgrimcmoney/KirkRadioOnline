import { createServer } from "node:http";
import { WebSocketServer } from "ws";
import app from "./app";
import { logger } from "./lib/logger";
import * as broadcast from "./lib/broadcast";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = createServer(app);

const wss = new WebSocketServer({ server, path: "/api/broadcast/ws" });

wss.on("connection", (ws) => {
  logger.info("Broadcast audio socket connected");

  ws.on("message", (data, isBinary) => {
    if (!isBinary) {
      return;
    }
    const chunk = Array.isArray(data)
      ? Buffer.concat(data)
      : Buffer.isBuffer(data)
        ? data
        : Buffer.from(data);
    broadcast.writeChunk(chunk);
  });

  ws.on("close", () => {
    logger.info("Broadcast audio socket disconnected");
    broadcast.stop();
  });

  ws.on("error", (err) => {
    logger.error({ err }, "Broadcast audio socket error");
  });
});

server.listen(port, (err?: Error) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
