import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { logger } from "./logger";

interface BroadcastState {
  isLive: boolean;
  streamTitle: string | null;
  startedAt: string | null;
  mount: string | null;
}

let state: BroadcastState = {
  isLive: false,
  streamTitle: null,
  startedAt: null,
  mount: null,
};

let ffmpegProc: ChildProcessWithoutNullStreams | null = null;

function readStreamEnv() {
  const host = process.env["KIRKRADIO_STREAM_HOST"];
  const port = process.env["KIRKRADIO_STREAM_PORT"];
  const mount = process.env["KIRKRADIO_STREAM_MOUNT"];
  const username = process.env["KIRKRADIO_STREAM_USERNAME"] || "source";
  const password = process.env["KIRKRADIO_STREAM_PASSWORD"];
  return { host, port, mount, username, password };
}

export function isConfigured(): boolean {
  const { host, port, mount, password } = readStreamEnv();
  return Boolean(host && port && mount && password);
}

export function getStatus(): BroadcastState & { configured: boolean } {
  return { ...state, configured: isConfigured() };
}

function normalizedMount(mount: string): string {
  return mount.startsWith("/") ? mount : `/${mount}`;
}

export function start(streamTitle: string): void {
  if (state.isLive) {
    throw new Error("A broadcast is already live");
  }

  const { host, port, mount, username, password } = readStreamEnv();
  if (!host || !port || !mount || !password) {
    throw new Error("Kirk Radio stream credentials are not configured");
  }

  const mountPath = normalizedMount(mount);
  const encodedUser = encodeURIComponent(username);
  const encodedPass = encodeURIComponent(password);
  const icecastUrl = `icecast://${encodedUser}:${encodedPass}@${host}:${port}${mountPath}`;

  const proc = spawn(
    "ffmpeg",
    [
      "-hide_banner",
      "-loglevel",
      "warning",
      "-f",
      "webm",
      "-i",
      "pipe:0",
      "-vn",
      "-acodec",
      "libmp3lame",
      "-b:a",
      "128k",
      "-content_type",
      "audio/mpeg",
      "-ice_name",
      streamTitle,
      "-f",
      "mp3",
      icecastUrl,
    ],
    { stdio: ["pipe", "pipe", "pipe"] },
  );

  proc.stderr.on("data", (chunk: Buffer) => {
    logger.debug({ line: chunk.toString().trim() }, "ffmpeg broadcast output");
  });

  proc.on("exit", (code, signal) => {
    logger.info({ code, signal }, "Broadcast ffmpeg process exited");
    if (ffmpegProc === proc) {
      ffmpegProc = null;
      state = { isLive: false, streamTitle: null, startedAt: null, mount: null };
    }
  });

  proc.on("error", (err) => {
    logger.error({ err }, "Broadcast ffmpeg process error");
  });

  ffmpegProc = proc;
  state = {
    isLive: true,
    streamTitle,
    startedAt: new Date().toISOString(),
    mount: mountPath,
  };

  logger.info({ mount: mountPath, streamTitle }, "Broadcast started");
}

export function stop(): void {
  if (ffmpegProc) {
    const proc = ffmpegProc;
    ffmpegProc = null;
    try {
      proc.stdin.end();
    } catch {
      // stdin may already be closed
    }
    proc.kill("SIGTERM");
  }
  state = { isLive: false, streamTitle: null, startedAt: null, mount: null };
  logger.info("Broadcast stopped");
}

export function writeChunk(chunk: Buffer): void {
  if (ffmpegProc && state.isLive && !ffmpegProc.stdin.destroyed) {
    ffmpegProc.stdin.write(chunk);
  }
}
