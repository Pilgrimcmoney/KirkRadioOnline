import { Router, type IRouter } from "express";
import {
  GetBroadcastStatusResponse,
  StartBroadcastBody,
  StartBroadcastResponse,
  StopBroadcastResponse,
} from "@workspace/api-zod";
import * as broadcast from "../lib/broadcast";

const router: IRouter = Router();

router.get("/broadcast/status", (_req, res): void => {
  res.json(GetBroadcastStatusResponse.parse(broadcast.getStatus()));
});

router.post("/broadcast/start", (req, res): void => {
  const parsed = StartBroadcastBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    broadcast.start(parsed.data.streamTitle);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to start broadcast";
    req.log.warn({ err }, "Failed to start broadcast");
    res.status(400).json({ error: message });
    return;
  }

  res.json(StartBroadcastResponse.parse(broadcast.getStatus()));
});

router.post("/broadcast/stop", (_req, res): void => {
  broadcast.stop();
  res.json(StopBroadcastResponse.parse(broadcast.getStatus()));
});

export default router;
