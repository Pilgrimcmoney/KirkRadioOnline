---
name: Browser mic/audio to Icecast broadcasting
description: How to relay live Web Audio API output from a browser app to a real Icecast/Shoutcast radio stream (e.g. Caster.fm-hosted stations).
---

Browsers cannot open a raw TCP/Icecast source connection themselves, so live
broadcasting from a web app needs a small relay on the backend:

1. **Client side**: route the Web Audio mix into an
   `audioContext.createMediaStreamDestination()` node (in addition to normal
   speaker output), then record that `MediaStream` with `MediaRecorder`
   (`audio/webm;codecs=opus`, short timeslice e.g. 250ms) and send each chunk
   as binary data over a WebSocket to the backend as it's produced.
2. **Server side**: on WS connection, pipe incoming binary chunks into a
   long-running `ffmpeg` child process's stdin (`-f webm -i pipe:0`), and have
   ffmpeg transcode to MP3/AAC and push it directly to the Icecast mount using
   ffmpeg's native icecast output: `-f mp3 icecast://user:pass@host:port/mount`.
   No separate Icecast client library is needed — ffmpeg speaks the protocol.
3. Tie the ffmpeg process lifecycle to the WebSocket connection (start on
   connect/POST /broadcast/start, kill on disconnect/POST /broadcast/stop) so
   a dropped connection doesn't leave a silent stream live.
4. Treat the stream host/port/mount/username/password as server-only secrets;
   never expose them to the client — only expose a `configured: boolean` flag.

**Why:** this avoids needing any native Icecast source library in Node — ffmpeg
already implements the Icecast source protocol and handles encoding in one step.
**How to apply:** any "go live to my existing internet radio station" feature
built as a web app with a Node/Express backend.
